#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <omp.h>
#include <sys/time.h>

/*variable globale pour d�terminer si le fichier contient un header ou pas*/




                                             /*split le fichier en entr�e en plusieurs fichiers selon le nombre de threads.*/
 double get_time(){
 struct timeval tv;
 gettimeofday(&tv,(void*)0);
 return (double)tv.tv_sec+tv.tv_usec*1e-6;
 }

void json_final(){
    char* fil="tmpcat.json";
    char* tmp="catalogue.json";
	FILE *fw,*fd;
    fw=fopen(fil,"r");
    fd=fopen(tmp,"w");
    char ligne_lue[12220];
    char* ligne="}";
    char* ch="},";
      while(fgets(ligne_lue,12220,fw)!=NULL){
             if(strcmp(ligne_lue,ch)==0){
                        fprintf(fd,"%s",ligne);
                        }
             else
                 fprintf(fd,"%s",ligne_lue);
       }
       fclose(fw);
       fclose(fd);
       system("rm tmpcat.json");
}

void start_catalogue(int nbth){
    FILE *fl;
    fl=fopen("tmpcat.json","w");
    fprintf(fl,"{\n");
    fprintf(fl,"\"number_of_threads\":%d,\n",nbth);
    fprintf(fl,"\"threads\":[\n");
    fclose(fl);
}

void stop_catalogue(){
    FILE *fl;
    fl=fopen("catalogue.json","a");
    fprintf(fl,"]\n");
    fprintf(fl,"}\n");
    fclose(fl);
}

void create_catalogue_file(int id_th,int nbth,int HB,int deb,int fin, char* my_file_name){
    FILE *fl;
    fl=fopen("tmpcat.json","a");
    fprintf(fl,"{\n");
    fprintf(fl,"\"thread_id\":%d,\n",id_th);
    fprintf(fl,"\"block_height\":%d,\n",HB);
    fprintf(fl,"\"block_start\":%d,\n",deb-1);
    fprintf(fl,"\"block_stop\":%d,\n",fin-1);
    fprintf(fl,"\"thread_name_file\":\"%s\"\n",my_file_name);
    fprintf(fl,"},");
    fclose(fl);
}
void call_catalogue_file(int id_th,int nbth,int HB,int deb,int fin, char* my_file_name){
    // start_catalogue(nbth);
//      #pragma omp ordered
  //    {
        create_catalogue_file(id_th,nbth,HB,deb,fin,my_file_name);
   //   }
     //stop_catalogue();
}

void get_lenght_matrix(char* filename,int* lig,int* col){
    FILE *fw;
    fw=fopen(filename,"r");
    char ligne_lue[12220];
    char seps[]=" ,\n,;,\t";
    char *token;
   
    int number_token=0;
    fgets(ligne_lue,12220,fw);
    int colo=*col,lige=*lig;
    colo=0;
    token=strtok(ligne_lue,seps);


    while(token!=NULL)
        {
             colo++;
         /* Get next token: */
         token=strtok(NULL,seps);
        }


    while(fgets(ligne_lue,12220,fw)!=NULL){
                        number_token++;
                    }
        lige=number_token;

   *col=colo;
   *lig=lige;
  }
void init_info(int lig,int* HB,int* ideb,int* ifin,int* tid,int* nthreads){
    int Q,R;
    int idb=*ideb,ifn=*ifin,td=*tid,nth=*nthreads,HDB=*HB;
 //obtain and print thread variable local
  td = omp_get_thread_num();
  nth= omp_get_num_threads();
  if (tid==0){  printf("number of threads:%d\n",nth);}
  Q=lig/nth;
  //printf("Q:%d\n",Q);
  R=lig%nth;
  //printf("R:%d\n",R);
  if(td<R){
    HDB=Q+1;
    idb=1+td*(Q+1);
    ifn=idb+HDB;
  }
  else{
    HDB=Q;
    idb=1+R*(Q+1)+(td-R)*Q;
    ifn=idb+HDB;
  }
   //printf("tid=%3d,[ideb,ifin[=[%4d,%4d[,HB=%4d\n",td,idb,ifn,HDB);
   *HB=HDB;*tid=td;*ideb=idb;*ifin=ifn;*nthreads=nth;
}

void read_file_th(char* filename,int col,int ideb,int ifin,int HB,int tid,int nth,char* th_file,int* hr){
     int i,ii,j,hd;
     char ligne_lue[12220];
     FILE* file_n;
     FILE* file_th=NULL;
     char ext[256]=".csv";
     char tid_s[256];
      hd=1;
     char nomfil[4048];
     char tab_file[nth][4048];
     for(j=0;j<nth;++j){
	    strcpy(nomfil,th_file);
		sprintf(tid_s,"%d",j+1);
		strcat(nomfil,tid_s);
		strcat(nomfil,ext);
		strcpy(tab_file[j],nomfil);
		 }
     //start_catalogue(nth);
     //printf("%d\n",hd);
    #pragma omp parallel private(tid_s,nomfil)
    {
		if(file_th==NULL){
			file_th=fopen(tab_file[tid],"w");
		}
		file_n=fopen(filename,"r");
		if(file_n==NULL)
			printf("\nOpen %s failed.\n",filename);
		fgets(ligne_lue,12220,file_n);
		if(hd==1){
			fprintf(file_th,"%s",ligne_lue);
			fclose(file_n);
		}
		file_n=fopen(filename,"r");
		for(ii=0;ii<ideb;++ii){
			fgets(ligne_lue,12220,file_n);
		}
		for(i=ideb;i<ifin;++i){
			fgets(ligne_lue,12220,file_n);
			fprintf(file_th,"%s",ligne_lue);
		}
	fclose(file_n);
	fclose(file_th);
	}
	//call_catalogue_file(tid,nth,HB,ideb,ifin,tab_file[tid]);
}

void split_file(char** filenam,int* nthreads,char** nomfil,int * nblg, int *nbcl){
     char* filename;
     char* nomfile;
     int j,i,jj,vf=0;
     double start,stop,t;
     FILE *fr;
     char ligne_lue[12220];
     char ext[256]=".csv";
     char tid_s[256];
     char nomfill[4048];
    char comp_let[53]={'"','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z',
                       'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
     for(jj=0;jj<1;jj++){
        filename=filenam[0];
        nomfile=nomfil[0];
       }
      fr=fopen(filename,"r");
       //file with header or not
      fgets(ligne_lue,12220,fr);
     // printf("%s\n",ligne_lue);
      while(j<strlen(ligne_lue)){
          for(i=0;i<53;++i){
            //printf("%c\n",ligne_lue[i]);
            //printf("%c\n",comp_let[i]);
              if(ligne_lue[j]==comp_let[i]){
                  //printf("%c\n",ligne_lue[0]);
                  printf("file with header\n");
                  vf=1;
                  break;
               }
           }
        break;
        j++;
      }

       fclose(fr);
     int lg,cl,HB,ideb,ifin,tid,nth;
     nth=*nthreads;
     get_lenght_matrix(filename,&lg,&cl);
     *nblg=lg;
     *nbcl=cl;
 //   printf("Number of rows=%d\n, Number of cols=%d\n",*nblg,*nbcl);
    if(nth==0){
        start=get_time();
         #pragma omp parallel private(tid,HB,ideb,ifin)
        {
            init_info(lg,&HB,&ideb,&ifin,&tid,&nth);
           // printf("tid=%3d,[ideb,ifin[=[%4d,%4d[,HB=%4d\n",tid,ideb,ifin,HB);
            read_file_th(filename,cl,ideb,ifin,HB,tid,nth,nomfile,&vf);
            printf("split done done!!!\n");

        }
        stop=get_time();
        t=stop-start;
        printf("Time to split:\t %lf\n",t);
        //json_final();
    }

    else{
         start=get_time();
        #pragma omp parallel num_threads(nth) private(tid,HB,ideb,ifin)
            {
                init_info(lg,&HB,&ideb,&ifin,&tid,&nth);
                //printf("tid=%3d,[ideb,ifin[=[%4d,%4d[,HB=%4d\n",tid,ideb,ifin,HB);
                read_file_th(filename,cl,ideb,ifin,HB,tid,nth,nomfile,&vf);
                printf("split done done!!!\n");
            }
        
        stop=get_time();
        t=stop-start;
        printf("Time to split:\t %lf\n",t);

       }
    start_catalogue(nth); 
    
    #pragma omp ordered
    {
		strcpy(nomfill,nomfile);
		sprintf(tid_s,"%d",tid+1);
		strcat(nomfill,tid_s);
		strcat(nomfill,ext);
		call_catalogue_file(tid,nth,HB,ideb,ifin,nomfill);		
	}
   json_final();
   stop_catalogue();
}



