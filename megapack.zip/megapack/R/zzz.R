.onLoad<-function(lib,pkg){
    library.dynam("megapack",pkg,lib)
}
