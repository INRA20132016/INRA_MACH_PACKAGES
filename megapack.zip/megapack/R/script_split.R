# -*- coding: utf-8 -*-

psplit<-function(file1,nbth,file2){
out <- .C("split_file",as.character(file1),as.integer(nbth),as.character(file2),ligne=as.integer(0),colo=as.integer(0),PACKAGE="megapack");
#################################################################
####
#### Code de découpage des Fichiers
####
#################################################################

#################################################################
## Creation des fichiers R d'utilisation des fichiers decoupes
#catalog <- fromJSON(file="catalogue.json")

#for (i in 1:catalog$number_of_threads) {
  #print("toto")
  #filename <- catalog$threads[i][[1]]$thread_name_file
  #r_filename <- paste(filename,".R",sep="")
 # script <- paste("data <- read.table('", filename,"',header=TRUE)",sep="")
  #print(script)
#  fileConn<-file(r_filename)
 # writeLines(script, fileConn)
 # close(fileConn)
#}
return (out)
}


