#include <stdio.h>
#include <stdlib.h>

void gpuNumberofDevice(int* Nbdevice){
	system("nvidia-smi | grep P0 | wc -l > tmp.txt");
	FILE * fr;
	fr=fopen("tmp.txt","r");
	int Nbdevic;
	Nbdevic=*Nbdevice;
	char ligne_lue[3];
	fgets(ligne_lue,3,fr);
	Nbdevic=atoi(ligne_lue);
	*Nbdevice=Nbdevic;
	printf("Number of GPU Devices string: %s\n",ligne_lue);
	printf("Number of GPU Devices int: %d \n",Nbdevic);
	system("rm tmp.txt");
}


int main(){
    int Nb;
	gpuNumberofDevice(&Nb);
	
	return 0;
}	
