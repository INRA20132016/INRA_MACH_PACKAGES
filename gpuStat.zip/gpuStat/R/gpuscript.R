slave_compute_pearson<-function(){
	
	library("gputools")
	themethod<-character(50)
	namesmallfile<-character(100)
#	memsize<-integer(1)
#	unty<-character(7)
	
	themethod<-mpi.recv.Robj(0,1,1,0)
	namesmallfile<-mpi.recv.Robj(0,1,1,0)
#	memsize<-mpi.recv.Robj(0,1,1,0)
#	unty<-mpi.recv.Robj(0,1,1,0)
	data <- read.table(paste(namesmallfile,mpi.comm.rank(),".csv",sep=""),header=TRUE)
	#source(paste(namesmallfile,mpi.comm.rank(),".csv.R",sep=""))
	n.f=nrow(data)
	n.o=ncol(data)
	
	thevector<-data[1,]
	if(length(thevector)!=nrow(t(data))){stop("Vector must have the same length that ncol of the matrix")}
	
#	if(unty=="MBytes"){
		mem<-1000000*1023
#else{mem=memsize}
	memoctet<-mem/8
	memfloat<-memoctet/8
	matrixmem<-n.f*n.o*8
	
	if(matrixmem<=memfloat){loadblock=0}else{loadblock=1}
	
	if(loadblock==1){
		nb=memfloat%/%n.o
		loopLenght=n.f%/%nb
	}else{loopLenght=1}	

	gpuID<-chooseGpu(deviceId=mpi.comm.rank()-1)
	
	if(loopLenght>1){
		qs=n.f%/%loopLenght
		r=n.f%%loopLenght
		submatrix_hbd=rep(NA,loopLenght)
		submatrix_sideb=rep(NA,loopLenght)
		submatrix_sifin=rep(NA,loopLenght)
	
		for(i in 1:loopLenght){
			if(i-1<r){
				submatrix_hbd[i]=qs+1
				submatrix_sideb[i]=(1+i-1)*(qs+1)
				submatrix_sifin[i]=submatrix_sideb[i]+submatrix_hbd[i]-1}else{
				submatrix_hbd[i]=qs
				submatrix_sideb[i]=1+r*(qs+1)+(i-1-r)*qs
				submatrix_sifin[i]=submatrix_sideb[i]+submatrix_hbd[i]-1}
		 }
		
		gpupearf<-NULL
		tpsgpu<-NULL
		usr<-0.0
		sys<-0.0
		elap<-0.0
		for(j in 1:loopLenght){
				tpsgputmp<-system.time(gpupeartmp<-gpuCor(t(data[submatrix_sideb[j]:submatrix_sifin[j],1:n.o]),thevector,method=themethod))
			
				gpupearf<-c(gpupearf,gpupeartmp$coefficients)
				usr<-usr+tpsgputmp[1]
				sys<-sys+tpsgputmp[2]
				elap<-elap+tpsgputmp[3]
			}
		tpsgpu<-c(usr,sys,elap)
	}else{
	     tpsgpu<-system.time(gpupearf<-gpuCor(t(data),thevector,method=themethod)$coefficients)}

		 
	result<-c(length(gpupearf))
    result
}


init.data<-function(thefile,namesmallfile,thevector,themethod){
	#library("megapack")
	#respack<-psplit(thefile,8,namesmallfile)
	#respack$ligne
	#respack$colo
	mpi.spawn.Rslaves(nslaves=8)
	
	for(p in 1:8){
		mpi.send.Robj(themethod,p,1,1)
		mpi.send.Robj(namesmallfile,p,1,1)
	}
	
	#dyn.load("getsizegpumemory.so")
	#out<-.C("gpuGlobalSize",memsize=as.integer(1),unty=as.character(1))
	
	#for(p in 1:8){
#		mpi.send.Robj(out$memsize,p,1,1)
	#	mpi.send.Robj(out$unty,p,1,1)
	#}
	
	mpi.bcast.Robj2slave(slave_compute_pearson)
	res<-mpi.remote.exec(slave_compute_pearson())
	mpi.close.Rslaves()
	return(res)
}

uu<-commandArgs();
vv<-commandArgs(TRUE);

thefile=uu[6]
namesmallfile=uu[7]
thevector=as.vector(uu[8])
themethod=uu[9]

library("Rmpi")

timemasterslave<-system.time(result<-init.data(thefile,namesmallfile,thevector,themethod))
result$slave1
timemasterslave

timemasterslave<-system.time(result<-init.data("data_gene_profiles_3.9M_genes_292_samples.csv","data_gene_profiles"))
thevector<-data_gene_profiles[,1]
length(thevector)
datacsv<-read.table("data2export.csv",header=TRUE)
cgpu<-gpuCor(t(datacsv),datacsv[1,],method="pearson")
cgpu$coefficients
ccpu<-cor(t(datacsv),datacsv[,1],method="pearson")
ccpu
length(cgpu$coefficients)
length(ccpu)
ecart1=ccpu-cgpu$coefficients
sum(ecart1>1e-10)
