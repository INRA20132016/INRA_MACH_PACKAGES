init.gpuHost<-function(thefile,nameinitfile){
library("megapack")
respack<-psplit(thefile,2,nameinitfile)
}


pCor<-function(thefile,namesmallfile,user,thevector,themethod){
init.gpuHost(thefile,"gpufile")

system(paste("scp ","gpufile","1.csv"," ",user,"@","gpuopy1",":.",sep=""))
system(paste("scp ","gpufile","2.csv"," ",user,"@","gpuopy2",":.",sep=""))

system(paste("scp ","gpuscript.R"," ",user,"@","gpuopy1",":.",sep=""))
system(paste("scp ","gpuscript.R"," ",user,"@","gpuopy2",":.",sep=""))

gpu1file="gpufile1.csv"
gpu2file="gpufile2.csv"

system(paste("ssh ",user,"@","gpuopy1"," Rscript gpuscript.R ",gpu1file," ",namesmallfile," ",thevector," ",themethod,sep=""))
system(paste("ssh ",user,"@","gpuopy2"," Rscript gpuscript.R ",gpu2file," ",namesmallfile," ",thevector," ",themethod,sep=""))
}


